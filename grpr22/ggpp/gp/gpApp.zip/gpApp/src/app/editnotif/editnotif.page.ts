import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editnotif',
  templateUrl: './editnotif.page.html',
  styleUrls: ['./editnotif.page.scss'],
})
export class EditnotifPage implements OnInit {

  public hide: boolean=true;
  constructor() { }

  ngOnInit() {
  }

}

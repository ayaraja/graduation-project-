import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancelactivity',
  templateUrl: './cancelactivity.page.html',
  styleUrls: ['./cancelactivity.page.scss'],
})
export class CancelactivityPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

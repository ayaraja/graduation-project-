import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-choosenotif',
  templateUrl: './choosenotif.page.html',
  styleUrls: ['./choosenotif.page.scss'],
})
export class ChoosenotifPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

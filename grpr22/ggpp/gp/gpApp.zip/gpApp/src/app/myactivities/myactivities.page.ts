import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myactivities',
  templateUrl: './myactivities.page.html',
  styleUrls: ['./myactivities.page.scss'],
})
export class MyactivitiesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

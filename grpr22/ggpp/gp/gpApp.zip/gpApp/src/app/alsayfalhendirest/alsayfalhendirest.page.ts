import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alsayfalhendirest',
  templateUrl: './alsayfalhendirest.page.html',
  styleUrls: ['./alsayfalhendirest.page.scss'],
})
export class AlsayfalhendirestPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

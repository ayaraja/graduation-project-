export interface Fav {
    id: string;
    person: string;
    text: string;
    time: string;
    date: string;
    cost: string;
    numVisit: string;
    typeJ: string;
    vistType: string;
    location: string;
  }
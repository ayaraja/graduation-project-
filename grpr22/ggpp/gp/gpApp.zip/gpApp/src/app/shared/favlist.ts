export default [
    {
      category: 'restaurants',
      favorites: [
        {
            id: '1',
            person: 'الصيف الهندي',
            text:'عن المكان:     الصيف الهندي يزدهر لجعل كل ضيف مع القائمةالمتنوعةونوعية الطعام يشعر بالارتياح وكأنه في بيته',
            time: ' الوقت :من م12:30 م 2:00',
            date: 'may 2019 اليوم والتاريخ :الخميس 12',
            cost: '200 :التكلفة',
            numVisit: '4 :عدد الزوار',
            typeJ: ' :نوع الجلسة داخلية ',
            vistType: 'عائلات',
            location: ''
        }
      ],
      icon: 'brush'
    }
];